import React from 'react';

const DeleteUserButton = ({ userId }) => {
    const handleDelete = () => {
        // Send request to backend API to delete the user
        fetch(`/users/${userId}`, {
                method: 'DELETE',
            })
            .then((response) => {
                // Handle successful response, if needed
                console.log('User deleted');
            })
            .catch((error) => {
                // Handle error from the backend API
                console.error('Failed to delete the user:', error);
            });
    };

    return <button onClick = { handleDelete } > Delete < /button>;
};

export default DeleteUserButton;