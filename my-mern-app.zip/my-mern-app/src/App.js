const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const db = require('./db'); // Import the MongoDB connection
const User = require('./models/user'); // Assuming you have a User model defined

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Get all users
app.get('/users', async(req, res) => {
    try {
        const users = await User.find();
        res.json(users);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch users' });
    }
});

// Create a new user
app.post('/users', async(req, res) => {
    try {
        const newUser = new User(req.body);
        await newUser.save();
        res.status(201).json(newUser);
    } catch (err) {
        res.status(400).json({ error: 'Failed to create a new user' });
    }
});

const port = 5000; // You can use any available port
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});

function validateUser(req, res, next) {
    const { username, email, password } = req.body;
    if (!username || !email || !password) {
        return res.status(400).json({ error: 'All fields are required' });
    }
    // Add more validation as needed
    next();
}

// Create a new user
app.post('/users', validateUser, async(req, res) => {
    try {
        const newUser = new User(req.body);
        await newUser.save();
        res.status(201).json(newUser);
    } catch (err) {
        res.status(400).json({ error: 'Failed to create a new user' });
    }
});