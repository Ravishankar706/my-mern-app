import React, { useState } from 'react';

const UpdateUserForm = ({ user }) => {
        const [username, setUsername] = useState(user.username);
        const [email, setEmail] = useState(user.email);
        const [error, setError] = useState('');

        const handleSubmit = (e) => {
            e.preventDefault();
            // Perform client-side input validation
            if (!username || !email) {
                setError('All fields are required');
                return;
            }

            // Send data to backend API to update the user
            const updatedUser = { username, email };
            fetch(`/users/${user._id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(updatedUser),
                })
                .then((response) => response.json())
                .then((data) => {
                    // Handle successful response, if needed
                    console.log('User updated:', data);
                })
                .catch((error) => {
                    // Handle error from the backend API
                    setError('Failed to update the user');
                });
        };

        return ( <
            div >
            <
            h2 > Update User < /h2> {
                error && < div className = "error" > { error } < /div>} <
                    form onSubmit = { handleSubmit } >
                    <
                    div >
                    <
                    label > Username: < /label> <
                    input
                type = "text"
                value = { username }
                onChange = {
                    (e) => setUsername(e.target.value) }
                /> <
                /div> <
                div >
                    <
                    label > Email: < /label> <
                    input
                type = "email"
                value = { email }
                onChange = {
                    (e) => setEmail(e.target.value) }
                /> <
                /div> <
                button type = "submit" > Update User < /button> <
                    /form> <
                    /div>
            );
        };

        export default UpdateUserForm;