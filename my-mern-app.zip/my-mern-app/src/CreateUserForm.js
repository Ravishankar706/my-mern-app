import React, { useState } from 'react';

const CreateUserForm = () => {
        const [username, setUsername] = useState('');
        const [email, setEmail] = useState('');
        const [error, setError] = useState('');

        const handleSubmit = (e) => {
            e.preventDefault();
            // Perform client-side input validation
            if (!username || !email) {
                setError('All fields are required');
                return;
            }

            // Send data to backend API to create a new user
            const newUser = { username, email };
            fetch('/users', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(newUser),
                })
                .then((response) => response.json())
                .then((data) => {
                    // Handle successful response, if needed
                    console.log('New user created:', data);
                })
                .catch((error) => {
                    // Handle error from the backend API
                    setError('Failed to create a new user');
                });
        };

        return ( <
            div >
            <
            h2 > Create New User < /h2> {
                error && < div className = "error" > { error } < /div>} <
                    form onSubmit = { handleSubmit } >
                    <
                    div >
                    <
                    label > Username: < /label> <
                    input
                type = "text"
                value = { username }
                onChange = {
                    (e) => setUsername(e.target.value) }
                /> <
                /div> <
                div >
                    <
                    label > Email: < /label> <
                    input
                type = "email"
                value = { email }
                onChange = {
                    (e) => setEmail(e.target.value) }
                /> <
                /div> <
                button type = "submit" > Create User < /button> <
                    /form> <
                    /div>
            );
        };

        export default CreateUserForm;